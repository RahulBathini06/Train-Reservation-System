package com.train;

import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        String action = req.getParameter("action");

        try {
            Connection con = DBConnection.getConnection();

            // View ticket
            if ("view".equals(action)) {
                res.sendRedirect("ticket.jsp?pnr=" +
                        req.getParameter("pnr").trim());
                return;
            }

            // Cancel ticket
            if ("cancel".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "UPDATE bookings SET status='CANCELLED' WHERE pnr=?");
                ps.setLong(1, Long.parseLong(req.getParameter("pnr").trim()));
                ps.executeUpdate();

                res.sendRedirect("ticket.jsp?pnr=" +
                        req.getParameter("pnr").trim());
                return;
            }

            // Book ticket
            int count = Integer.parseInt(req.getParameter("count"));
            int trainNo = Integer.parseInt(req.getParameter("trainNo"));
            String date = req.getParameter("date");
            String trainClass = req.getParameter("trainClass");

            PreparedStatement t = con.prepareStatement(
                "SELECT fare,seats FROM trains WHERE train_no=?");
            t.setInt(1, trainNo);
            ResultSet tr = t.executeQuery();
            tr.next();

            int baseFare = tr.getInt("fare");
int seats = tr.getInt("seats");
int fare = baseFare;

if (trainClass.equals("3AC"))
    fare = (int)(baseFare * 1.5);
else if (trainClass.equals("2AC"))
    fare = baseFare * 2;
else if (trainClass.equals("1AC"))
    fare = (int)(baseFare * 2.5);

            if (count > seats) {
                res.getWriter().println("Not enough seats available.");
                return;
            }

            // Find available seats
            boolean[] used = new boolean[seats + 1];

            PreparedStatement s = con.prepareStatement(
                "SELECT seat_no FROM bookings " +
                "WHERE train_no=? AND journey_date=? AND status='CONFIRMED'");
            s.setInt(1, trainNo);
            s.setString(2, date);

            ResultSet sr = s.executeQuery();
            while (sr.next())
                if (sr.getInt("seat_no") <= seats)
                    used[sr.getInt("seat_no")] = true;

            long pnr = System.currentTimeMillis() % 10000000000L;

            PreparedStatement b = con.prepareStatement(
    "INSERT INTO bookings " +
    "(pnr,passenger_no,train_no,passenger_name,age,gender,journey_date,train_class,seat_no,fare,status) " +
    "VALUES (?,?,?,?,?,?,?,?,?,?,?)");

            int passenger = 0;

            for (int i = 1; i <= count; i++) {

                int seat = 1;
                while (used[seat]) seat++;
                used[seat] = true;

                b.setLong(1, pnr);
                b.setInt(2, ++passenger);
                b.setInt(3, trainNo);
                b.setString(4, req.getParameter("name" + i));
                b.setInt(5, Integer.parseInt(req.getParameter("age" + i)));
                b.setString(6, req.getParameter("gender" + i));
                b.setString(7, date);
                b.setString(8, trainClass);
                b.setInt(9, seat);
                b.setInt(10, fare);
                b.setString(11, "CONFIRMED");

                b.executeUpdate();
            }

            con.close();

            res.sendRedirect("ticket.jsp?pnr=" + pnr);

        } catch (Exception e) {
            res.getWriter().println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
package com.train;

import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/TrainServlet")
public class TrainServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM trains " +
                "WHERE UPPER(source)=UPPER(?) " +
                "AND UPPER(destination)=UPPER(?)"
            );

            ps.setString(1, req.getParameter("source"));
            ps.setString(2, req.getParameter("destination"));

            ResultSet rs = ps.executeQuery();

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");

            out.println("<meta charset='UTF-8'>");
            out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
            out.println("<title>RailGo - Available Trains</title>");
           out.println("<div class='logo'>RailGo</div>");
            out.println("<link rel='stylesheet' href='css/style.css'>");

            out.println("</head>");
            out.println("<body>");

            /* HEADER */

            out.println("<header>");
            out.println("<div class='logo'>🚆 RailGo</div>");

            out.println("<nav>");
            out.println("<a href='index.jsp'>Home</a>");
            out.println("<a href='index.jsp#tickets'>My Tickets</a>");
            out.println("</nav>");

            out.println("</header>");

            /* MAIN */

            out.println("<div class='page'>");

            out.println("<div class='tag'>TRAIN SEARCH</div>");
            out.println("<h1>Available Trains</h1>");

            out.println("<p class='sub'>");
            out.println("Choose a train for your journey from ");
            out.println("<b>" + req.getParameter("source") + "</b>");
            out.println(" to ");
            out.println("<b>" + req.getParameter("destination") + "</b>.");
            out.println("</p>");

            boolean found = false;

            while (rs.next()) {

                found = true;

                out.println("<div class='train-card'>");

                out.println("<h2>" +
                    rs.getString("train_name") +
                    "</h2>");

                out.println("<p><b>Train No:</b> " +
                    rs.getInt("train_no") +
                    "</p>");

                out.println("<div class='route'>");

                out.println("<div>");
                out.println("<small>FROM</small>");
                out.println("<b>" +
                    rs.getString("source") +
                    "</b>");
                out.println("</div>");

                out.println("<div>");
                out.println("<span>→</span>");
                out.println("</div>");

                out.println("<div>");
                out.println("<small>TO</small>");
                out.println("<b>" +
                    rs.getString("destination") +
                    "</b>");
                out.println("</div>");

                out.println("</div>");

                out.println("<div class='info'>");

                out.println("<div>");
                out.println("<small>DEPARTURE</small>");
                out.println("<b>" +
                    rs.getString("departure") +
                    "</b>");
                out.println("</div>");

                out.println("<div>");
                out.println("<small>ARRIVAL</small>");
                out.println("<b>" +
                    rs.getString("arrival") +
                    "</b>");
                out.println("</div>");

                out.println("<div>");
                out.println("<small>BASE FARE</small>");
                out.println("<b>₹" +
                    rs.getInt("fare") +
                    "</b>");
                out.println("</div>");

                out.println("<div>");
                out.println("<small>SEATS</small>");
                out.println("<b>" +
                    rs.getInt("seats") +
                    "</b>");
                out.println("</div>");

                out.println("</div>");

                out.println(
                    "<a href='booking.jsp?trainNo=" +
                    rs.getInt("train_no") +
                    "'>Book Ticket →</a>"
                );

                out.println("</div>");
            }

            if (!found) {

                out.println("<div class='panel'>");

                out.println("<h2>No trains found</h2>");

                out.println("<p>");
                out.println("No trains are available for this route.");
                out.println("</p>");

                out.println("</div>");
            }

            out.println("<br>");
            out.println("<a href='index.jsp'>← Back to Home</a>");

            out.println("</div>");

            out.println("</body>");
            out.println("</html>");

            con.close();

        } catch (Exception e) {

            out.println("<h2>Error</h2>");
            out.println("<p>" + e.getMessage() + "</p>");

        }
    }
}
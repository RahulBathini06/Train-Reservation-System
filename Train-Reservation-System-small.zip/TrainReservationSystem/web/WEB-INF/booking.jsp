<!DOCTYPE html>

<html>

<head>
    <title>Book Train Ticket</title>
</head>

<body>

<h1>Book Train Ticket</h1>

<form action="BookingServlet" method="post">

    <input type="hidden" name="action"  value="book">
    Train Number:

    <input type="text"name="trainNo" value="<%=request.getParameter("trainNo")%>" readonly>

    <br><br>

    Passenger Name:

    <input type="text" name="name" required>

    <br><br>

    Age:
    <input type="number" name="age" min="1"  max="120" required>

    <br><br>

    Gender:
    <select name="gender">
        <option>Male</option>
        <option>Female</option>
        <option>Other</option>
    </select>

    <br><br>

    Journey Date:
    <input type="date" name="date"  required>
    <br><br>

    Class:
    <select name="trainClass">
        <option value="Sleeper">  Sleeper   </option>
        <option value="3AC">3AC   </option>
        <option value="2AC"> 2AC </option>
        <option value="1AC"> 1AC </option>

    </select>
    <br><br>
    <input type="submit" value="Book Ticket">

</form>

<br>

<a href="index.jsp">
    Back to Home
</a>

</body>

</html>